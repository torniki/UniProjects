﻿using System;
using System.Text.RegularExpressions;
using System.Globalization;
using PolStrLib;

namespace DllTest
{
	class TestDLL
	{
		static void Main(string[] args)
		{
			string expr = "x^4+1";
			string pstr;
			PolStr.StrToPolStr(expr, out pstr, 0);
			if (PolStr.Error == Error.OK)
			{
				Console.WriteLine(pstr);
				Console.WriteLine("{0} = {1}", expr, PolStr.EvalPolStr(pstr, 1, 0));
				Console.WriteLine("{0}' = {1}", expr, PolStr.EvalPolStr(pstr, 1, 1));
				Console.WriteLine("{0}'' = {1}", expr, PolStr.EvalPolStr(pstr, 1, 2));
			}
			else Console.WriteLine(PolStr.Error);
			/*Regex r = new Regex(@"((\.\d+)|(\d+(\.\d*)?))((e|E)(\+|\-)?\d+)?");
			// .5
			// 12
			// 12.
			// 12.5
			Match m = r.Match("4+2");
			Console.WriteLine(m.Value);
			Console.WriteLine(m.Captures.Count);
			Console.WriteLine(double.Parse("12.", CultureInfo.InvariantCulture));*/
		}
	}
}
